import csv
import jieba
from sklearn import svm
import numpy as np
import string

def knnreader():
    fp=open('train.csv',encoding='utf-8')
    train=csv.reader(fp)
    num_train=0
    
    words_train=[]
    list_words=[]
    for item in train:
        mydict={}
        content=[]
        if item[1]!='情感倾向':
            content=jieba.lcut_for_search(item[0])
            content=partdel(content)
            list_words.append(item[1])
            num_train+=1
            for word in content:
                mydict[word]=mydict.get(word,1)
            words_train.append(mydict)
    fp.close()
    return words_train,list_words,num_train

def knn(words_train,list_word,num_train,max_k):
    fp1=open('test_labled.csv',encoding='utf-8')
    test=csv.reader(fp1)
    tp=[]
    fp=[]
    fn=[]
    tn=[]
    times=0
    for i in range(max_k):
        tp.append(0)
        fp.append(0)
        tn.append(0)
        fn.append(0)
    for item in test:
        if item[1]!='情感倾向':
            times+=1
            mydict={}
            #if times==50:
                #break
            content=jieba.lcut_for_search(item[0])
            compare=[]
            calc=0
            list_words=[]
            for i in range(num_train):
                list_words.append(list_word[i])
            for word in content:
                mydict[word]=mydict.get(word,0)+1
            for i in range(num_train):
                calc=0
                for key in mydict:
                    calc+=words_train[i].get(key,0)
                compare.append(calc)
            #print(list_words[0],list_words[1],list_words[2],list_words[3],list_words[4])
            #print(compare[0],compare[1],compare[2],compare[3],compare[4],compare[5])
            compare,list_words=rank(compare,list_words,num_train,max_k)
            #print(list_words[0],list_words[1],list_words[2],list_words[3],list_words[4])
            #print(compare[0],compare[1],compare[2],compare[3],compare[4],compare[5])
            for k in range(1,max_k+1):
                ispositive=ismid=isnegtive=0
                for i in range(k):
                    if list_words[i]=='1':
                        ispositive+=1
                    elif list_words[i]=='0':
                        ismid+=1
                    elif list_words[i]=='-1':
                        isnegtive+=1
                if ispositive>ismid:
                    if ispositive>isnegtive:
                        if item[1]=='1':
                            tp[k-1]+=1
                        elif item[1]=='-1':
                            fn[k-1]+=1
                    else:
                        if item[1]=='1':
                            fp[k-1]+=1
                        elif item[1]=='-1':
                            tn[k-1]+=1
                else:
                    if ismid>=isnegtive:
                        if item[1]=='1':
                            fp[k-1]+=1
                        elif item[1]=='-1':
                            fn[k-1]+=1
                    else:
                        if item[1]=='1':
                            fp[k-1]+=1
                        elif item[1]=='-1':
                            tn[k-1]+=1
                #print(ispositive,ismid,isnegtive,item[1])
    print('KNN:')
    for k in range(max_k):
        print('K=%d'%(k+1))
        print('tp=',tp[k],';fp=',fp[k])
        print('fn=',fn[k],';tn=',tn[k])
    fp1.close()
    return 0

            
def rank(array1,array2,num,max_k):
    for i in range(max_k-1):
        for l in range(i,num-1):
            j=num-l-2
            if array1[j]<array1[j+1]:
                index=array1[j]
                array1[j]=array1[j+1]
                array1[j+1]=index
                index=array2[j]
                array2[j]=array2[j+1]
                array2[j+1]=index
    return array1,array2

def bayes():
    negtive={}
    mid={}
    positive={}
    train_1=[]
    train0=[]
    train1=[]
    words=[]
    fp=open('train.csv',encoding='utf-8')
    train=csv.reader(fp)
    for item in train:
        words=jieba.lcut_for_search(item[0])
        words=partdel(words)
        if item[1]=='-1':
            train_1+=words
        elif item[1]=='0':
            train0+=words
        elif item[1]=='1':
            train1+=words
    elem_1=elem0=elem1=elem=0
    for word in train_1:
        negtive[word]=negtive.get(word,0)+1
        elem_1+=1
    for word in train0:
        mid[word]=mid.get(word,0)+1
        elem0+=1
    for word in train1:
        positive[word]=positive.get(word,0)+1
        elem1+=1
    elem=elem_1+elem0+elem1
    fp.close()   
    fp1=open('test_labled.csv',encoding='utf-8')
    fp2=open('out_Bayes.csv','a+',encoding='utf-8')
    test=csv.reader(fp1)
    out=csv.writer(fp2)
    tp=fp=fn=tn=0
    for item in test:
        words=jieba.lcut(item[0])
        ispositive=ismid=isnegtive=1
        for word in words:
            if positive.get(word,0)+mid.get(word,0)+negtive.get(word,0)!=0:
                ispositive*=(positive.get(word,1)*elem)/(elem1*(positive.get(word,0)+mid.get(word,0)+negtive.get(word,0)))
                ismid     *=(mid.get(word,1)*elem)/(elem0*(positive.get(word,0)+mid.get(word,0)+negtive.get(word,0)))
                isnegtive *=(negtive.get(word,1)*elem)/(elem_1*(positive.get(word,0)+mid.get(word,0)+negtive.get(word,0)))
        ispositive*=elem1/elem
        ismid*=elem0/elem
        isnegtive*=elem_1/elem
        if ispositive>ismid:
            if ispositive>isnegtive:
                if item[1]=='1':
                    tp+=1
                elif item[1]=='-1':
                    fn+=1
                item+='1'
            else:
                if item[1]=='1':
                    fp+=1
                elif item[1]=='-1':
                    tn+=1
                item+=['-1']
        else:
            if ismid>isnegtive:
                if item[1]=='1':
                    fp+=1
                elif item[1]=='-1':
                    fn+=1
                item+='0'
            else:
                if item[1]=='1':
                    fp+=1
                elif item[1]=='-1':
                    tn+=1
                item+=['-1']
        out.writerow(item)
    fp1.close()
    fp2.close()
    print('Bayes:')
    print('tp=',tp,';fp=',fp)
    print('fn=',fn,';tn=',tn)
    return 0

def svm_reader(fname):
    fp=open(fname,encoding='utf-8')
    train=csv.reader(fp)
    x=[]
    y=[]
    wordlist=['中国', '加油', '一起', '医护', '致敬', '所有', '前线', '工作', '和', '们', '辛苦', '你们', '我们', '平安', '都', '在', '等', '一线', '的', '疫情', '一个', '人', '2020', '年', '是', '第一', '这', '也', '就是', '一定', '能', '会', '医生', '新型', '冠状', '病毒', '冠状病毒', '大', '什么', '医院', '患者', '对', '来', 'L', '视频', '为', '小',  '要', '武汉', '抗击', '已', '防护', '中', '一心', '展开', '全文', 'c', '我', '希望', '有', '肺炎', '到', '了', '消息', '护人', '人员', '医护人员', '好', '自己', '被', '全国', '人民', '看', '真的', '可以', '很', '给', '更', '多', '国家', '爱', '吧', '哈哈', '哈哈哈', '愿', '你', '战斗', '不', '做', '又', '治愈', '再', '2', '\ue627', '努力', '勇战', '要强', '这个', '战疫', '捐赠', 'O', '防控', '说', '想', '去', '医务', '奋战', '日', '确诊', '出院', '医疗', '医疗队', '支援', '向', '感谢', '啊', '口罩', '战', '微博', '没有', '着', '健康', '李易峰', '蒙牛', '白衣', '天使', '白衣天使', '企业', '公益', '行动', '大家', '带', '让', '今天', '与', '生活', '请', '感染', '抗疫', '战士', '湖北', '将', '还', '起来', '最', '打赢', '就', '他', '肖战', '病例', '用', '月', '网页', '链接', '朱一龙', '新冠', '从', '上', '他们', '1', '万众', '万众一心', '打卡', '空气', '呼吸', '大学', '一', '重症', '医学', '后', '时', '不要', '\u3000', '现在', '如果', '症状', '无症状', '可能', '传染', '丁香', '发热', '隔离', '发现', '不能', '因为', '而', '情况', '不是', '中医', '医药', '中医药', '可', '卫健委', '传播', '接触', '9', '发布', '已经', '天', '死亡', '组织', '开始', '新闻', '卫生',  '时间', '12', '北京', '专家', '事件', '进行', '10', '高速', '目前', '4', '5', '咳嗽', '没', '怎么', '知道', '病人', '她', '发烧',  '但', '公共', '公共卫生', '中心', '号', '新增', '例', '累计', '上班', '时候', '密切', '吗', '还是', '名', '吃', '过', '3', '者', '志愿', '愿者', '志愿者', '需要', '把', '治疗', '问题', '最新', '个', '出现', '无', '研究', '密切接触', '突发', '开学', '疑似', '或', '检测', '下', '看到', '太', '这种', '谁', '野味', '死', '一下', '那', '还有', '得', '在家', '一天', '里', '为什么', '呢', '不会', '一直', '体温', '应该', '这么', '但是', '感觉', '觉得', '这些', '这样', '蝙蝠', '才', '每天', '那么', '出来', '阴谋']
    times=0
    for item in train:
        words=[]
        if item[1]!='情感倾向':
            words_train=jieba.lcut_for_search(item[0])
            words_train=partdel(words_train)
            for word in wordlist:
                if word in words_train:
                    words.append(1)
                else :
                    words.append(0)
            x.append(words)
            y.append(int(item[1]))
    return x,y

def mysvm():
    x,y=svm_reader(fname='train.csv')
    clf=svm.SVC(gamma='scale')
    clf.fit(x,y)
    test,mark=svm_reader(fname='test_labled.csv')
    predict=clf.predict(test)
    tp=tn=fp=fn=0
    for i in range(len(mark)):
        if mark[i]==1:
            if predict[i]==1:
                tp+=1
            else:
                fp+=1
        elif mark[i]==-1:
            if predict[i]==-1:
                tn+=1
            else:
                fn+=1
    print('SVM:')
    print('tp=',tp,';fp=',fp)
    print('fn=',fn,';tn=',tn)
    return 0


def partdel(list_for_del):
    for word in '\#；:/-?！？…。：‘“”’，《。》/？@！（）*…~·—=+*/、|【】{}':
        for words in list_for_del:
            if word in words:
                list_for_del.remove(words)
    return list_for_del

if __name__ == '__main__':
    words_train,list_words,num_train=knnreader()
    knn(words_train,list_words,num_train,30)
    wordlist=bayes()
    mysvm()
