

def count(word_list):
    word_count={}
    num=0
    for word in word_list:
        word_count[word]=word_count.get(word,0)+1
        num+=1
    return word_count,num

def calc(words,ham_count,spam_count,num_ham,num_spam):
    pham=1
    pspam=1
    for word in words:
        if spam_count.get(word,0)+ham_count.get(word,0)!=0:
            pham*=ham_count.get(word,1)/num_ham
            pspam*=spam_count.get(word,1)/num_spam
    if pham>pspam:
        return 1
    else:
        return 0


def train():
    ham_words=[]
    spam_words=[]
    num_ham=0
    num_spam=0
    for num in range(1,21):
        ham_email=open('ham\%d.txt'%num,'r')
        spam_email=open('spam\%d.txt'%num,'r')
        ham_content=ham_email.read()
        spam_content=spam_email.read()
        ham_words+=ham_content.split()
        spam_words+=spam_content.split()
        ham_email.close()
        spam_email.close()

    spam_count,num_spam=count(spam_words)
    ham_count,num_ham=count(ham_words)
    return ham_count,spam_count,num_ham,num_spam

def test(ham_count,spam_count,num_ham,num_spam):
    for num in range(21,26):
        test_ham=open('ham\%d.txt'%num,'r')
        test_spam=open('spam\%d.txt'%num,'r')
        ham_content=test_ham.read()
        spam_content=test_spam.read()
        ham_words=ham_content.split()
        spam_words=spam_content.split()
        if calc(ham_words,ham_count,spam_count,num_ham,num_spam)==1:
            print('number:%d belong to ham:True'%num)
        else:
            print('number:%d belong to ham:False'%num)
        if calc(spam_words,ham_count,spam_count,num_ham,num_spam)==0:
            print('number:%d belong to spam:True'%num)
        else:
            print('number:%d belong to spam:False'%num)

if __name__ == '__main__':
    ham_count,spam_count,num_ham,num_spam=train()
    test(ham_count,spam_count,num_ham,num_spam)
